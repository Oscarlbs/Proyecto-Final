package vista;

import java.util.Scanner;

import controlador.ArticuloController;
import modelo.Postres;

public class VistaArticulo {

	private static ArticuloController controlador;
	private static Scanner sc = new Scanner(System.in);
	
	public static void menu () {
		
		controlador = new ArticuloController();
		
		int option = -1;
		do {
			try {
				System.out.println("BIENVENIDO AL MEN� DE LA PIZZER�A LAS DIVINAS: ");
				System.out.println("0. Salir del programa.");
				System.out.println("1. A�adir nuevos art�culos.");
				System.out.println("2. Modificar art�culos existentes.");
				System.out.println("3. Listar los art�culos");
				System.out.println("4. Ver el resumen de los tickets usando la vista de la BD.");
				System.out.println("5. Ver el resumen de los art�culos m�s vendidos.");
				System.out.println("6. Borrar articulo.");
				option = Integer.parseInt(sc.nextLine());
				switch (option) {
				case 0:
					System.out.println("Fin del programa.");
					break;
				case 1:
						crearArtic();
				case 2:
					break;
				case 3:
					controlador.listarArts();
					break;
				case 4:
					break;
				case 5:
					break;
				case 6:
					int cod;
					System.out.println("Introduce el codigo del art�culo que quieres borrar");
					cod = sc.nextInt();
					controlador.borrarArt(cod);
					break;
				default:
					System.out.println("Por favor, seleccione una opci�n disponible.");
					break;
				}
			} catch (NumberFormatException e) {
				System.out.println("Debe introducir un n�mero.");
			}
		} while (option != 0);	
	}
	private static void crearArtic() {
		String art;
		boolean rep = true;
		do {
		System.out.println("Que art�culo quiere insertar?");
		System.out.println("1. Pizza");
		System.out.println("2. Bebida");
		System.out.println("3. Postre");
		System.out.println("4. Volver al men�");
		
		art = sc.nextLine();
		
		switch(art) {
		case "1": crearPizza();
			break;
		case "2": crearBebida();
			break;
		case "3": crearPostre();
			break;
		case "4": System.out.println("Volviendo al men�");
		System.out.println("==================");
		rep=false;
			break;
		default: System.out.println("Opci�n mal introducida, int�ntelo de nuevo");
			break;
		}
		}while(rep==true);
		
	}
	private static void crearPostre() {
		
		String name;
		int stock,id;
		float price;
		Postres p;
		
		System.out.println("Introduce el nombre del nuevo postre");
		name = sc.nextLine();
		
		System.out.println("Indique cuanto stock existe del postre");
		stock = Integer.parseInt(sc.nextLine());
		
		System.out.println("Indique cuantos euros vale cada unidad de su postre");
		price = Float.parseFloat(sc.nextLine());
		
		controlador.crearPostreController(stock,price,name);
		
	}
	private static void crearBebida() {
		// TODO Auto-generated method stub
		
	}
	private static void crearPizza() {
		// TODO Auto-generated method stub
		
	}
	public void listarArts() {
		
		
	}
	
}
