drop database if exists cafeteria;

create database cafeteria;

use cafeteria;

create table articulo (

cod_art int auto_increment primary key,
stock int null,
precio float not null
);

create table ticket (

cod_tick int primary key,
fecha_hora timestamp not null
);

create table ticket_articulo (

art int,
tick int,
art_vend int not null,

primary key (art,tick),

foreign key (art) references articulo(cod_art)
	on delete cascade
	on update cascade,
	
foreign key (tick) references ticket(cod_tick)
	on delete cascade
	on update cascade
);

create table bebidas (

art_b int,
tip_bebidas enum('agua','coca_cola','fanta','nestea','aquarius','sprite','limonada','gaseosa','batido','cerveza') null,

foreign key (art_b) references articulo(cod_art)
	on delete cascade
	on update cascade
);

create table pinchos (
art_p int,
tipo_pincho ('tortilla','chorizo','ternera','pulpo','queso','huevo','cerdo','salmon','jam�n','lomo'),
tipos ('pincho', 'tapa', 'racion'),
alergenos ('lacteos','carnicos','pescado','marisco', 'aceites','huevo','harina','nueces','almendras','gluten'),
foreign key (art_p) references articulo(cod_art)
	on delete cascade
	on update cascade
);

create table alergenos (

art_p2 int,
num_alergenos enum('lacteos','carnicos','pescado','marisco', 'aceites','huevo','harina','nueces','almendras','gluten' ),

foreign key (art_p2) references articulo(cod_art)
	on delete cascade
	on update cascade
);

insert into articulo (cod_art,stock,precio) VALUES

( '1' , '20' , '10.50' ),
( '2' , '10' , '16.25' ),
( '3' , '15' , '10.50' ),
( '4' , '16' , '12.50' ),
( '5' , '13' , '15.50' ),
( '6' , '7'  , '22.20' ),
( '7' , '12' , '20.50' ),
( '8' , '8'  , '18.50' ),
( '9' , '14' , '19.00' ),
( '10', '11' , '16.30' ),
( '11', '12' , '2.50' ),
( '12', '50' , '3.50' ),
( '13', '11' , '3.50' ),
( '14', '25' , '3.00' ),
( '15', '50' , '2.50' ),
( '16', '60' , '3.00' ),
( '17', '20' , '2.50' ),
( '18', '60' , '2.00' ),
( '19', '40' , '2.00' ),
( '20', '60' , '3.00' ),
( '21', '43' , '2.50' ),
( '22', '44' , '3.00' ),
( '23', '84' , '2.50' ),
( '24', '27' , '1.50' ),
( '25', '34' , '4.00' ),
( '26', '42' , '1.00' ),
( '27', '73' , '1.50' ),
( '28', '45' , '2.50' ),
( '29', '58' , '2.00' ),
( '30', '34' , '2.50' );

insert into ticket (cod_tick,fecha_hora) VALUES

( '1'  , '2022-01-22 12:15:53.00' ),
( '2'  , '2022-03-12 09:25:12.00' ),
( '3'  , '2022-04-22 05:55:38.00' ),
( '4'  , '2022-04-11 10:15:50.00' ),
( '5'  , '2022-07-05 22:08:51.00' ),
( '6'  , '2022-07-07 12:09:52.00' ),
( '7'  , '2022-07-13 02:10:53.00' ),
( '8'  , '2022-07-14 06:13:14.00' ),
( '9'  , '2022-10-04 09:14:03.00' ),
( '10' , '2022-11-08 11:11:21.00' );

insert into ticket_articulo (art,tick,art_vend) VALUES

( '1'  , '1' , '5'  ),
( '2'  , '2' , '3'  ),
( '3'  , '3' , '6'  ),
( '4'  , '4' , '2'  ),
( '5'  , '5' , '4'  ),
( '6'  , '6' , '5'  ),
( '7'  , '7' , '10' ),
( '16'  , '8' , '12' ),
( '9'  , '9' , '3'  ),
( '22' , '10', '6'  );


insert into bebidas (art_b,tip_bebidas) VALUES

( '1'  , 'agua'),
( '2'  , 'coca_cola'),
( '3'  , 'sprite'),
( '4'  , 'fanta'),
( '5'  , 'cerveza'),
( '6'  , 'nestea'),
( '7'  , 'aquarius'),
( '8'  , 'gaseosa'	),
( '9'  , 'limonada'),
( '10' , 'batido');


insert into pinchos (art_p,tipo,tipo,alergenos) VALUES

('tortilla','chorizo','ternera','pulpo','queso','huevo','cerdo','salmon','jam�n','aceituna'),

( '11','pincho','tortilla','huevo'),
( '12','pincho','chorizo','carnicos'),
( '13','pincho','ternera','carnicos'),
( '14','pincho','pulpo','mariscos'),
( '15','tapa','queso','lacteos'),
( '16','tapa','huevo','huevo'),
( '17','racion','cerdo','carnicos'),
( '18','tapa','salmon','pescado'),
( '19','tapa','jam�n','carnicos'),
( '20','tapa','lomo','carnicos');


insert into alergenos (art_p2,tip_alergenos) VALUES

( '21'  , 'lacteos'	),
( '22'  , 'carnicos'),
( '23'  , 'pescado'),
( '24'  , 'marisco'),
( '25'  , 'aceites'	),
( '26'  , 'huevo'),
( '27'  , 'harina'),
( '28'  , 'nueces'	),
( '29'  , 'almendras'),
( '30'  , 'gluten');


# 1. Triggers de evitar ventas si no hay stock
# 2. Trigger para reducir stock con cada nuevo ticket que se a�ada.(Ventas)

delimiter $$

drop trigger if exists evitar_reducir_ventas $$
create trigger evitar_reducir_ventas 
after insert on ticket_articulo for each row

begin
	
	declare aux_stock int;
	declare resultado int;
	
	select a.stock into aux_stock
	from ticket_articulo ta 
	inner join articulo a on ta.art = a.cod_art 
	where ta.art = new.art;
	
	if (new.art_vend > aux_stock)
	then
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "Error, no disponemos de tanto stock";
	else 
		set resultado = aux_stock - new.art_vend;
	
		update articulo a set a.stock = resultado where a.cod_art = new.art;
	end if;
end;
$$

delimiter ;


#******************************************************
#PRUEBA TRIGGER NO HAY STOCK

/*

insert into articulo (cod_art,stock,precio) values
('31' , '4' , '5.0');

insert into ticket (cod_tick,fecha_hora) values
('31' , '2022-11-08 11:11:21.00' );

insert into ticket_articulo (art,tick,art_vend) values
('31' , '2' , '10'); 

*/

#******************************************************
# PRUEBA TRIGGER ACTUALIZAR STOCK

/*

insert into articulo (cod_art,stock,precio) values
('31' , '9' , '5.0');

insert into ticket (cod_tick,fecha_hora) values
('31' , '2022-11-08 11:11:21.00' );

insert into ticket_articulo (art,tick,art_vend) values
('31' , '31' , '5'); 

select *
	from ticket_articulo ta 
	inner join articulo a on ta.art = a.cod_art 
	where ta.art = 31 ;

*/

# 3. Trigger para aumentar el stock con cada ticket que se borre.(Devoluciones)


delimiter $$ 

drop trigger if exists devoluciones $$
create trigger devoluciones 
before delete on ticket_articulo for each row

begin 
	
	declare aux_stock int;
	declare resultado int;

	select a.stock into aux_stock
	from ticket_articulo ta 
	inner join articulo a on ta.art = a.cod_art 
	where ta.art = old.art;

	set resultado = aux_stock + old.art_vend;
	update articulo a set a.stock = resultado where a.cod_art = old.art;
	
end;
$$

delimiter ;

#PRUEBAS TRIGGER AUMENTAR STOCK CON CADA TICKET BORRADO

/*

insert into articulo (cod_art,stock,precio) values
('31' , '11' , '5.0');

insert into ticket (cod_tick,fecha_hora) values
('31' , '2022-11-08 11:11:21.00' );

insert into ticket_articulo (art,tick,art_vend) values
('31' , '31' , '5'); 

select *
	from ticket_articulo ta 
	inner join articulo a on ta.art = a.cod_art 
	where ta.art = 31 ;

delete 
	from ticket_articulo ta 
	where ta.art = 31 ; 

select *
	from articulo a 
	where a.cod_art = 31;

*/

# 4. Trigger para aumentar o reducir el stock ante cambios en un ticket. (Devolucionesparciales).

/*
delimiter $$

drop trigger if exists update_stock $$ 
create trigger update_stock 
after update on ticket_articulo for each row 

begin 
	declare aux_stock int;
	declare resultado int;
	set resultado = aux_stock - new.art;

	select a.stock into aux_stock 
	from ticket_articulo ta 
	inner join articulo a on a.cod_art = ta.art 
	where a.cod_art = new.art;

	update pdate articulo set a.stock = aux_stock + new.art
	from 

	 
	
end;
$$

delimiter ;
*/
# 5. Vista para el Dependiente de los art�culos disponibles.

drop view if exists arts_disponibles ;
create view arts_disponibles as
select *
from articulo a 
left join pizzas p on p.art_p = a.cod_art 
left join bebidas b on b.art_b = a.cod_art 
left join postres p2 on p2.art_p2 = a.cod_art 
where a.stock > 0;

# 6. Vista resumen de los tickets para el administrador con los datos ordenados desde el ticket
# m�s actual al m�s antiguo.

drop view if exists resum_tickets ;
create view resum_tickets as
select *
from ticket t 
order by t.fecha_hora asc;

# 7. Vista resumen para el administrador con los datos de los 5 art�culos m�s vendidos

drop view if exists resum_art ;
create view resum_art as
select a.cod_art , p.*, b.*, p2.*, sum(ta.art_vend) as suma_precios
from articulo a 
left join pizzas p on p.art_p = a.cod_art 
left join bebidas b on b.art_b = a.cod_art 
left join postres p2 on p2.art_p2 = a.cod_art 
inner join ticket_articulo ta on ta.art = a.cod_art
group by a.cod_art  order by suma_precios desc;

# Creacion de los roles

drop role if exists administrador;
drop role if exists dependiente;

create role administrador;
create role dependiente ;

grant all privileges on resum_tickets to administrador ;
grant all privileges on resum_art to administrador;
grant all privileges on arts_disponibles to administrador;

grant insert, drop, select, update on resum_tickets to administrador;
grant insert, drop, select, update on resum_art to administrador;
grant select on arts_disponibles to dependiente;











