package vista;

import java.util.Scanner;

import controlador.ArticuloController;
import modelo.Postres;

public class VistaArticulo {

	private static ArticuloController controlador;
	private static Scanner sc = new Scanner(System.in);
	
	public static void menu () {
		
		controlador = new ArticuloController();
		
		int option = -1;
		do {
			try {
				System.out.println("BIENVENIDO AL MEN� DE LA PIZZER�A LAS DIVINAS: ");
				System.out.println("0. Salir del programa.");
				System.out.println("1. A�adir nuevos art�culos.");
				System.out.println("2. Modificar art�culos existentes.");
				System.out.println("3. Listar los art�culos");
				System.out.println("4. Ver el resumen de los tickets usando la vista de la BD.");
				System.out.println("5. Ver el resumen de los art�culos m�s vendidos.");
				System.out.println("6. Borrar articulo.");
				option = Integer.parseInt(sc.nextLine());
				switch (option) {
				case 0:
					System.out.println("Fin del programa.");
					break;
				case 1:
					crearArtic();
				case 2:
					break;
				case 3:
					controlador.listarArts();
					break;
				case 4:
					break;
				case 5:
					break;
				case 6:
					int cod;
					System.out.println("Introduce el codigo del art�culo que quieres borrar");
					cod = sc.nextInt();
					controlador.borrarArt(cod);
					break;
				default:
					System.out.println("Por favor, seleccione una opci�n disponible.");
					break;
				}
			} catch (NumberFormatException e) {
				System.out.println("Debe introducir un n�mero.");
			}
		} while (option != 0);	
	}
	private static void crearArtic() {
		String art;
		boolean rep = true;
		do {
		System.out.println("Que art�culo quiere insertar?");
		System.out.println("1. Pizza");
		System.out.println("2. Bebida");
		System.out.println("3. Postre");
		System.out.println("4. Volver al men�");
		
		art = sc.nextLine();
		
		switch(art) {
		case "1": crearPizza();
			break;
		case "2": crearBebida();
			break;
		case "3": crearPostre();
			break;
		case "4": System.out.println("Volviendo al men�");
		System.out.println("==================");
		rep=false;
			break;
		default: System.out.println("Opci�n mal introducida, int�ntelo de nuevo");
			break;
		}
		}while(rep==true);
		
	}
	private static void crearPostre() {
		
		String name,postre = null;
		int stock,id;
		float price;
		boolean rep = false;
		
		do {
		System.out.println("Introduce el n�mero del nuevo postre");
		System.out.println("1. helado");
		System.out.println("2. tarta");
		System.out.println("3. cafe");
		System.out.println("4. brownie");
		System.out.println("5. gofre");
		System.out.println("6. montadito");
		System.out.println("7. melocoton");
		System.out.println("8. yogur");
		System.out.println("9. manzana");
		System.out.println("10. flan");
		name = sc.nextLine();
		
		switch(name) {
		
		case "1": postre = "helado";
		rep = false;
			break;
		case "2": postre = "tarta";
		rep = false;
			break;
		case "3": postre = "cafe";
		rep = false;
			break;
		case "4": postre = "brownie";
		rep = false;
			break;
		case "5": postre = "gofre";
		rep = false;
			break;
		case "6": postre = "montadito";
		rep = false;
			break;
		case "7": postre = "melocoton";
		rep = false;
			break;
		case "8": postre = "yogur";
		rep = false;
			break;
		case "9": postre = "manzana";
		rep = false;
			break;
		case "10":postre = "flan";
		rep = false;
			break;
		default: System.out.println("Opci�n mal introducida, int�ntelo de nuevo");
		rep = true;
			break;
		}
		}while(rep == true);
		
		do {
		System.out.println("Indique cuanto stock existe del postre");
		stock = Integer.parseInt(sc.nextLine());
		
		if(igual_cero(stock)==false || negativo(stock)==false){
			System.out.println("Stock mal introducido, int�ntelo de nuevo");
		}
		}while(igual_cero(stock)==false || negativo(stock)==false);
		
		do {
		System.out.println("Indique cuantos euros vale cada unidad de su postre");
		price = Float.parseFloat(sc.nextLine());
		if (igual_cero(price)==false || negativo(price)==false) {
			System.out.println("Precio mal introducido, int�ntelo de nuevo");
		}
		}while(igual_cero(price)==false || negativo(price)==false);
		
		controlador.crearPostreController(stock,price,postre);
		
		System.out.println("Art�culo a�adido correctamente");
	}
	private static void crearBebida() {
	
		String name,bebida = null;
		int stock,id;
		float price;
		boolean rep = false;
		
		do {
		System.out.println("Introduce el n�mero de la nueva bebida");
		System.out.println("1. agua");
		System.out.println("2. coca cola");
		System.out.println("3. sprint");
		System.out.println("4. fanta");
		System.out.println("5. cerveza");
		System.out.println("6. nestea");
		System.out.println("7. aquarius");
		System.out.println("8. gaseosa");
		System.out.println("9. limonada");
		System.out.println("10. batido");
		bebida = sc.nextLine();

		switch(bebida) {
		
		case "1": bebida = "agua";
		rep = false;
			break;
		case "2": bebida = "coca_cola";
		rep = false;
			break;
		case "3": bebida = "sprint";
		rep = false;
			break;
		case "4": bebida = "fanta";
		rep = false;
			break;
		case "5": bebida = "cerveza";
		rep = false;
			break;
		case "6": bebida = "nestea";
		rep = false;
			break;
		case "7": bebida = "aquarius";
		rep = false;
			break;
		case "8": bebida = "gaseosa";
		rep = false;
			break;
		case "9": bebida = "limonada";
		rep = false;
			break;
		case "10":bebida = "batido";
		rep = false;
			break;
		default: System.out.println("Opci�n mal introducida, int�ntelo de nuevo");
		rep = true;
			break;
		}
		}while(rep == true);
		
		do {
		System.out.println("Indique cuanto stock existe de la bebida");
		stock = Integer.parseInt(sc.nextLine());
		
		if(igual_cero(stock)==false || negativo(stock)==false){
			System.out.println("Stock mal introducido, int�ntelo de nuevo");
		}
		}while(igual_cero(stock)==false || negativo(stock)==false);
		
		do {
		System.out.println("Indique cuantos euros vale cada unidad de su bebida");
		price = Float.parseFloat(sc.nextLine());
		if (igual_cero(price)==false || negativo(price)==false) {
			System.out.println("Precio mal introducido, int�ntelo de nuevo");
		}
		}while(igual_cero(price)==false || negativo(price)==false);
		
		controlador.crearBebidaController(stock,price,bebida);
		
		System.out.println("Art�culo a�adido correctamente");
	}
	private static void crearPizza() {
	
		String especialidad,tamanho,ingreds,num=null;
		int stock,id,num_ingredientes;
		float price;
		boolean rep = false;
		do {
		System.out.println("Introduce el tipo de pizza que quieres");
		System.out.println("1. Cuatro Quesos");
		System.out.println("2. Carbonara");
		System.out.println("3. Espa�ola");
		System.out.println("4. Mexicana");
		num = sc.nextLine();
		
		switch(num) {
		
		case "1": especialidad = "cuatro_quesos";
		ingreds = "mozzarella, queso azul, queso parmesano, queso ricotta";
		num_ingredientes = 4;
		rep = false;
			break;
		case "2": especialidad = "carbonara";
		ingreds = "mozzarella, nata, champinhones, pimienta negra, bacon";
		num_ingredientes = 5;
		rep = false;
			break;
		case "3": especialidad = "espanhola";
		ingreds = "salami, chorizo, bacon, tomate, mozzarella, pimienta, or�gano";
		num_ingredientes = 7;
		rep = false;
			break;
		case "4": especialidad = "mexicana";
		ingreds = "cebolla, pimenton dulce, mozzarella, aguacate, limon, chili, tabasco";
		num_ingredientes = 7;
		rep = false;
			break;
		default: System.out.println("Opci�n mal introducida, int�ntelo de nuevo");
		rep = true;
			break;
		}
		}while(rep==true);
		
		String num2;
		
		System.out.println("Introduce el tama�o de tu pizza");
		System.out.println("1. Peque�a");
		System.out.println("2. Mediana");
		System.out.println("3. Grande");
		num2 = sc.nextLine();
		
		switch(num2) {
		
		case "1": tamanho = "pequenia";
		rep = false;
			break;
		case "2": tamanho = "mediana";
		rep = false;
			break;
		case "3": tamanho = "grande";
		rep = false;
			break;
		default: System.out.println("Opci�n mal introducida, int�ntelo de nuevo");
		rep = true;
			break;
		}
	}

	public static boolean igual_cero (int valor) {
		if(valor==0) return false;
		else return true;
	}
	
	public static boolean negativo (int valor) {
		if(valor<0) return false;
		else return true;
	}
	public static boolean igual_cero (float valor) {
		if(valor==0) return false;
		else return true;
	}
	
	public static boolean negativo (float valor) {
		if(valor<0) return false;
		else return true;
	}	
}